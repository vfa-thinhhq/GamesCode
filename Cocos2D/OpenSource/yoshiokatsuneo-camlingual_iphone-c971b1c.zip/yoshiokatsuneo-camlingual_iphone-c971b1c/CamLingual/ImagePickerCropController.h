//
//  ImagePickerCropController.h
//  CamLingual
//
//  Created by Tsuneo Yoshioka on 8/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImagePickerCropController : UIViewController
- (IBAction)doTest:(id)sender;
- (IBAction)doCapture:(id)sender;
@end
