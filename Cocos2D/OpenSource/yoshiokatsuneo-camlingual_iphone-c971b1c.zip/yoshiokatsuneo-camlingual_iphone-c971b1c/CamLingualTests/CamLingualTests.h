//
//  CamLingualTests.h
//  CamLingualTests
//
//  Created by Tsuneo Yoshioka on 8/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CamLingualTests : SenTestCase

@end
