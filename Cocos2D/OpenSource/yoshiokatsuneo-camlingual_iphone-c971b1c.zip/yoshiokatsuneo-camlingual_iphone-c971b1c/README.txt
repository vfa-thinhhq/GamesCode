This is CamLingual's source code.

Copyright:
  Copyright (c) Yoshioka Tsuneo - all right reserved.
  And, the software may includes other software. See "About" page of iOS Settings menu(or "Settings.bundle/About.plist") for details.

Build:
  - Copy "Settings.bundle/OCRWebServiceAccount.plist-dummy" to "Settings.bundle/OCRWebServiceAccount.plist" and edit account information.
  - Copy "Settings.bundle/GoogleTranslateAccount.plist-dummy" to "GoogleTranslateAccount.plist" and edit GoogleTranslateAPI v2 account information.

License:
  You can choose license for this source code from below
    - GPL(GNU Public Licnese) version 2 or lator.
      (Except the case other license is written in the beginning of source.
       Some files have more loose MIT license.)
    - Other than GPL based on seperate agreement.
       If you want to use for other than GPL license, contact me with details for negotiation.

Contact address:
  CamLingual@gmail.com

