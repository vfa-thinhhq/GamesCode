#import <Foundation/Foundation.h>
#import "DDXMLNode.h"
#import "DDXMLPrivate.h"

@interface DDXMLNode (HTML)


+ (BOOL)isXmlDocPtr:(xmlKindPtr)kindPtr;

@end
